# Nyxvalle 1.0 — Android starter

Nyxvalle is a local-first Android UI and database prototype using Kotlin, Jetpack Compose, Room, and WorkManager dependency.

## Included
- Midnight / Electric Blue Compose interface
- Dashboard, account list, history placeholder, settings
- Local Room database for accounts, profiles, and timestamped change events
- Transactional snapshot reconciliation repository
- Account labels are local metadata only

## Important Instagram limitation
This starter intentionally does **not** log into Instagram, scrape pages, automate the Instagram app, collect session cookies, or bypass platform controls.

The official Instagram APIs do not provide a general-purpose endpoint for reading arbitrary personal accounts' complete followers/following lists. A future connector must use an officially supported permission and data source. Do not enter an Instagram password into this app.

The `reconcileSnapshot` function accepts a snapshot from a separately authorized and permitted source. It is the comparison/storage layer, not an Instagram collector.

## Open in Android Studio
1. Install Android Studio with Android SDK 35 and JDK 17.
2. Open this folder (`Nyxvalle`) as an existing Gradle project.
3. Allow Gradle sync.
4. Run the `app` configuration on an Android emulator or device.

The project does not include a Gradle wrapper. Android Studio can use its configured Gradle installation or generate wrapper files.

## Current status
This is a starter source project, not a signed APK and not a connected Instagram monitoring service. The 5-minute interval is a product preference only; Android periodic WorkManager jobs have a 15-minute minimum and are not exact alarms.


## Build an APK without installing Android Studio locally
A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`.
1. Create a private GitHub repository and upload the contents of this project.
2. Push the files to the `main` branch, or open the repository's Actions tab and run **Build Nyxvalle APK**.
3. Download the `Nyxvalle-debug-apk` artifact from the completed workflow run.
4. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from that file manager/browser.

This cloud build still requires a GitHub account and uploading the source project. The APK is not built until the workflow completes successfully.
