package com.nyxvalle.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [TrackedAccount::class, TrackedProfile::class, ChangeEvent::class],
    version = 1,
    exportSchema = false
)
abstract class NyxvalleDatabase : RoomDatabase() {
    abstract fun dao(): NyxvalleDao

    companion object {
        @Volatile private var INSTANCE: NyxvalleDatabase? = null

        fun get(context: Context): NyxvalleDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NyxvalleDatabase::class.java,
                    "nyxvalle.db"
                ).build().also { INSTANCE = it }
            }
    }
}
