package com.nyxvalle.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracked_accounts")
data class TrackedAccount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val platform: String = "Instagram",
    val username: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "profiles", primaryKeys = ["accountId", "platformUserId"])
data class TrackedProfile(
    val accountId: Long,
    val platformUserId: String,
    val username: String,
    val relationship: String, // "following" or "follower"
    val firstSeenAt: Long,
    val lastSeenAt: Long,
    val isPresent: Boolean = true
)

@Entity(tableName = "change_events")
data class ChangeEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: Long,
    val platformUserId: String,
    val usernameAtEvent: String,
    val relationship: String,
    val eventType: String, // "added" or "removed"
    val occurredAt: Long = System.currentTimeMillis(),
    val source: String = "local_import"
)
