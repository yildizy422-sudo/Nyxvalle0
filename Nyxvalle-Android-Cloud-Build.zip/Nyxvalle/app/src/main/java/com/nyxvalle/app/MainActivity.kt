package com.nyxvalle.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nyxvalle.app.data.NyxvalleDatabase
import com.nyxvalle.app.data.NyxvalleRepository
import com.nyxvalle.app.data.TrackedAccount
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080D18)
private val SurfaceN = Color(0xFF111D30)
private val Accent = Color(0xFF2583FF)
private val Muted = Color(0xFF91A4BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = NyxvalleRepository(NyxvalleDatabase.get(this))
        setContent { NyxvalleApp(repository) }
    }
}

@Composable
fun NyxvalleApp(repository: NyxvalleRepository) {
    var page by remember { mutableStateOf("Dashboard") }
    var selectedAccount by remember { mutableStateOf<TrackedAccount?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    val accounts by repository.accounts().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = SurfaceN,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = SurfaceN, contentColor = Color.White) {
                    listOf("Dashboard", "Accounts", "History", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Dashboard" -> Icons.Default.Dashboard
                                        "Accounts" -> Icons.Default.People
                                        "History" -> Icons.Default.History
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Color(0xFF19375F),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("NYXVALLE", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("SOCIAL TRACKING SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF19375F), shape = RoundedCornerShape(50)) {
                        Text("v1.0", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color(0xFF8CC4FF), fontSize = 12.sp)
                    }
                }

                when (page) {
                    "Dashboard" -> {
                        Text("Kontrol Merkezi", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                        Text("Hesap hareketlerinin genel görünümü", color = Muted)
                        InfoCard("İzlenen hesap", selectedAccount?.let { "@${it.username}" } ?: "Henüz hesap seçilmedi", "Instagram verileri henüz bağlanmadı")
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("Takip edilen", "—", Modifier.weight(1f))
                            StatCard("Takipçiler", "—", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("Yeni eklenen", "0", Modifier.weight(1f), Color(0xFF4ADE80))
                            StatCard("Çıkarılan", "0", Modifier.weight(1f), Color(0xFFFB7185))
                        }
                        InfoCard("Sistem durumu", "Hazır · Veri kaynağı bağlanmadı", "5 dakika kontrolü hedefi; Android arka plan ve platform erişim sınırlarına tabidir")
                    }
                    "Accounts" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Hesap yönetimi", Modifier.weight(1f), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                            Button(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("Ekle") }
                        }
                        if (accounts.isEmpty()) {
                            InfoCard("Henüz hesap yok", "İlk hesabını ekle", "Bu kayıt yalnızca yerel hesap etiketidir; Instagram'a giriş yapmaz.")
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(accounts) { account ->
                                    Card(
                                        onClick = { selectedAccount = account; page = "Dashboard" },
                                        colors = CardDefaults.cardColors(containerColor = SurfaceN)
                                    ) {
                                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                            Text("@${account.username}", fontWeight = FontWeight.SemiBold)
                                            Text("Instagram · Yerel kayıt", color = Muted, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    "History" -> {
                        Text("Değişiklik geçmişi", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                        InfoCard("Henüz hareket yok", "Kayıtlar burada görünecek", "Yeni eklenen ve çıkarılan hesapların zaman damgalı geçmişi tutulacak.")
                    }
                    else -> {
                        Text("Sistem ayarları", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                        SettingRow("Otomatik başlatma", "Açık")
                        SettingRow("Bildirimler", "Açık")
                        SettingRow("Otomatik yeniden deneme", "Açık")
                        SettingRow("Güvenli yedekleme", "Açık")
                        SettingRow("Kontrol aralığı", "5 dakika hedefi")
                        SettingRow("Senkronizasyon", "Telefon + Windows")
                        InfoCard("Veri güvenliği", "Yerel veritabanı", "Senkronizasyon ve Instagram bağlantısı sonraki geliştirme aşamalarında eklenecek.")
                    }
                }
            }
        }

        if (showAdd) {
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("Hesap etiketi ekle") },
                text = {
                    Column {
                        Text("Instagram kullanıcı adını gir. Bu işlem Instagram'a bağlanmaz.", color = Muted)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Kullanıcı adı") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (username.isNotBlank()) scope.launch {
                            repository.addAccount(username)
                            username = ""
                            showAdd = false
                        }
                    }) { Text("Kaydet") }
                },
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Vazgeç") } },
                containerColor = SurfaceN
            )
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceN), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier, tint: Color = Color.White) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = SurfaceN), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = tint, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceN)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Color.White)
            Text(value, color = Color(0xFF8CC4FF), fontSize = 13.sp)
        }
    }
}
