package com.nyxvalle.app.data

import androidx.room.withTransaction

class NyxvalleRepository(private val db: NyxvalleDatabase) {
    private val dao = db.dao()

    fun accounts() = dao.observeAccounts()
    fun profiles(accountId: Long, relationship: String) =
        dao.observeProfiles(accountId, relationship)
    fun events(accountId: Long) = dao.observeEvents(accountId)

    suspend fun addAccount(username: String): Long =
        dao.addAccount(TrackedAccount(username = username.trim().removePrefix("@")))

    /**
     * Reconciles a snapshot obtained through a permitted/authorized data source.
     * It records additions/removals transactionally and keeps the event history.
     * This function does not log in to Instagram or scrape Instagram pages.
     */
    suspend fun reconcileSnapshot(
        accountId: Long,
        relationship: String,
        snapshot: List<Pair<String, String>>,
        source: String
    ) = db.withTransaction {
        require(relationship == "following" || relationship == "follower")
        val now = System.currentTimeMillis()
        val previous = dao.currentProfiles(accountId, relationship)
        val incoming = snapshot.associateBy { it.first }
        val oldById = previous.associateBy { it.platformUserId }

        val events = mutableListOf<ChangeEvent>()

        snapshot.forEach { (platformId, username) ->
            val old = oldById[platformId]
            if (old == null || !old.isPresent) {
                events += ChangeEvent(
                    accountId = accountId,
                    platformUserId = platformId,
                    usernameAtEvent = username,
                    relationship = relationship,
                    eventType = "added",
                    occurredAt = now,
                    source = source
                )
            }
        }

        previous.filter { it.platformUserId !in incoming }.forEach { old ->
            events += ChangeEvent(
                accountId = accountId,
                platformUserId = old.platformUserId,
                usernameAtEvent = old.username,
                relationship = relationship,
                eventType = "removed",
                occurredAt = now,
                source = source
            )
        }

        val updated = snapshot.map { (platformId, username) ->
            val old = oldById[platformId]
            TrackedProfile(
                accountId = accountId,
                platformUserId = platformId,
                username = username,
                relationship = relationship,
                firstSeenAt = old?.firstSeenAt ?: now,
                lastSeenAt = now,
                isPresent = true
            )
        }
        dao.upsertProfiles(updated)
        events.forEach { /* kept in one transaction below */ }
        if (events.isNotEmpty()) dao.addEvents(events)

        // Keep removed records for history, but mark them absent in the current list.
        previous.filter { it.platformUserId !in incoming }.forEach { old ->
            dao.upsertProfiles(listOf(old.copy(isPresent = false, lastSeenAt = now)))
        }
    }
}
