package com.nyxvalle.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NyxvalleDao {
    @Query("SELECT * FROM tracked_accounts ORDER BY createdAt DESC")
    fun observeAccounts(): Flow<List<TrackedAccount>>

    @Insert
    suspend fun addAccount(account: TrackedAccount): Long

    @Query("SELECT * FROM profiles WHERE accountId = :accountId AND relationship = :relationship AND isPresent = 1 ORDER BY username COLLATE NOCASE")
    fun observeProfiles(accountId: Long, relationship: String): Flow<List<TrackedProfile>>

    @Query("SELECT * FROM change_events WHERE accountId = :accountId ORDER BY occurredAt DESC LIMIT 300")
    fun observeEvents(accountId: Long): Flow<List<ChangeEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfiles(profiles: List<TrackedProfile>)

    @Insert
    suspend fun addEvents(events: List<ChangeEvent>)

    @Query("SELECT * FROM profiles WHERE accountId = :accountId AND relationship = :relationship AND isPresent = 1")
    suspend fun currentProfiles(accountId: Long, relationship: String): List<TrackedProfile>

    @Query("UPDATE profiles SET isPresent = 0, lastSeenAt = :time WHERE accountId = :accountId AND relationship = :relationship")
    suspend fun markRelationshipAbsent(accountId: Long, relationship: String, time: Long)
}
